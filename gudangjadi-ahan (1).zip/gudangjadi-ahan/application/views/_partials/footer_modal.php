</body>
<!-- Footer End-->

<!-- Chat Box End-->
<!-- jquery
		============================================ -->
<script src="<?= base_url() ?>assets/js/vendor/jquery-1.11.3.min.js"></script>
<!-- bootstrap JS
		============================================ -->
<script src="<?= base_url() ?>assets/js/bootstrap.min.js"></script>
<!-- meanmenu JS
		============================================ -->
<script src="<?= base_url() ?>assets/js/jquery.meanmenu.js"></script>
<!-- mCustomScrollbar JS
		============================================ -->
<script src="<?= base_url() ?>assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
<!-- sticky JS
		============================================ -->
<script src="<?= base_url() ?>assets/js/jquery.sticky.js"></script>
<!-- scrollUp JS
		============================================ -->
<script src="<?= base_url() ?>assets/js/jquery.scrollUp.min.js"></script>
<!-- counterup JS
		============================================ -->
<script src="<?= base_url() ?>assets/js/counterup/jquery.counterup.min.js"></script>
<script src="<?= base_url() ?>assets/js/counterup/waypoints.min.js"></script>
<script src="<?= base_url() ?>assets/js/counterup/counterup-active.js"></script>
<!-- peity JS
		============================================ -->
<script src="<?= base_url() ?>assets/js/peity/jquery.peity.min.js"></script>
<script src="<?= base_url() ?>assets/js/peity/peity-active.js"></script>
<!-- sparkline JS
		============================================ -->
<script src="<?= base_url() ?>assets/js/sparkline/jquery.sparkline.min.js"></script>
<script src="<?= base_url() ?>assets/js/sparkline/sparkline-active.js"></script>
<!-- flot JS
		============================================ -->
<script src="<?= base_url() ?>assets/js/flot/jquery.flot.js"></script>
<script src="<?= base_url() ?>assets/js/flot/jquery.flot.tooltip.min.js"></script>
<script src="<?= base_url() ?>assets/js/flot/jquery.flot.spline.js"></script>
<script src="<?= base_url() ?>assets/js/flot/jquery.flot.resize.js"></script>
<script src="<?= base_url() ?>assets/js/flot/jquery.flot.pie.js"></script>
<script src="<?= base_url() ?>assets/js/flot/Chart.min.js"></script>
<script src="<?= base_url() ?>assets/js/flot/flot-active.js"></script>
<!-- map JS
		============================================ -->
<script src="<?= base_url() ?>assets/js/map/raphael.min.js"></script>
<script src="<?= base_url() ?>assets/js/map/jquery.mapael.js"></script>
<script src="<?= base_url() ?>assets/js/map/france_departments.js"></script>
<script src="<?= base_url() ?>assets/js/map/world_countries.js"></script>
<script src="<?= base_url() ?>assets/js/map/usa_states.js"></script>
<script src="<?= base_url() ?>assets/js/map/map-active.js"></script>
<!-- data table JS
		============================================ -->
<script src="<?= base_url() ?>assets/js/data-table/bootstrap-table.js"></script>
<script src="<?= base_url() ?>assets/js/data-table/tableExport.js"></script>
<script src="<?= base_url() ?>assets/js/data-table/data-table-active.js"></script>
<script src="<?= base_url() ?>assets/js/data-table/bootstrap-table-editable.js"></script>
<script src="<?= base_url() ?>assets/js/data-table/bootstrap-editable.js"></script>
<script src="<?= base_url() ?>assets/js/data-table/bootstrap-table-resizable.js"></script>
<script src="<?= base_url() ?>assets/js/data-table/colResizable-1.5.source.js"></script>
<script src="<?= base_url() ?>assets/js/data-table/bootstrap-table-export.js"></script>
<!-- switcher JS
		============================================ -->
<script src="<?= base_url() ?>assets/js/switcher/styleswitch.js"></script>
<script src="<?= base_url() ?>assets/js/switcher/switch-active.js"></script>
<!-- main JS
		============================================ -->
<script src="<?= base_url() ?>assets/js/main.js"></script>
<!-- jquery JS -->
<script src="<?= base_url() ?>assets/js/jquery-3.2.1.min.js"></script>
<script src="<?= base_url() ?>assets/js/counterup/jquery.waypoints.min.js"></script>
<script src="<?= base_url() ?>assets/js/counterup/jquery.counterup.min.js"></script>
<!-- select2 -->
<script src="<?= base_url() ?>assets/select2-master/dist/js/select2.min.js"></script>
<!-- sweetalert2 -->
<script src="<?= base_url() ?>assets/sweetalert2/swal2.js"></script>