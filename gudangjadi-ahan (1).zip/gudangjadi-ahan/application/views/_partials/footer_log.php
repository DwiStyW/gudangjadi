<!--   Core JS Files   -->
<script src="<?= base_url()?>assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="<?= base_url()?>assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<script src="<?= base_url()?>assets/js/plugins/perfect-scrollbar.min.js"></script>
<!--  Plugin for Parallax, full documentation here: https://github.com/wagerfield/parallax  -->
<script src="<?= base_url()?>assets/js/plugins/parallax.min.js"></script>
<!-- Control Center for Soft UI Kit: parallax effects, scripts for the example pages etc -->
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDTTfWur0PDbZWPr7Pmq8K3jiDp0_xUziI"></script>
<script src="<?= base_url()?>assets/js/soft-design-system.min.js?v=1.0.9" type="text/javascript"></script>
</body>

</html>