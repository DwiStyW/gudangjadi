<?php 
class Scan_detailsal extends CI_Controller{
    public function index(){
        $this->load->view("track/scan_detailsal");
    }
}